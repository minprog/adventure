# import loader

class Adventure():

    # Create rooms and items for the game that was specified at the command line
    def __init__(self, filename):
        self._current_room = loader.load_room_graph(filename)

    # Pass along the description of the current room, be it short or long
    def room_description(self):
        return self._current_room.description()

    # Move to a different room by changing "current" room, if possible
    def move(self, direction):
        # TODO
        pass


if __name__ == "__main__":

    from sys import argv

    # Check command line arguments
    if len(argv) not in [1,2]:
        print("Usage: python3 adventure.py [name]")
        exit(1)

    # Load the requested game or else Tiny
    print("Loading...")
    if len(argv) == 2:
        game_name = argv[1]
    elif len(argv) == 1:
        game_name = "Tiny"
    filename = f"data/{game_name}Adv.dat"

    # Create game
    adventure = Adventure(filename)

    # Welcome user
    print("Welcome to Adventure.\n")

    # Print very first room description
    print(adventure.room_description())

    # Prompt the user for commands until they type QUIT
    while True:

        # Prompt, converting all input to upper case
        command = input("> ").upper()

        # Perform the move or other command
        # TODO

        # Allows player to exit the game loop
        if command == "QUIT":
            break
